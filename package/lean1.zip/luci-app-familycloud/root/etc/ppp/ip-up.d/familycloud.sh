#!/bin/sh

sleep 60 && /etc/init.d/familycloud restart
