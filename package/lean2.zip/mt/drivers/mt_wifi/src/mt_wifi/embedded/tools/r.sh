ifconfig ra0 down
rmmod mt7603e_ap
